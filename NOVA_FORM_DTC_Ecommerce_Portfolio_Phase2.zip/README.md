# NOVA FORM — DTC E-commerce Portfolio Demo

**Personal demo project by Adrian Satria Putra**

NOVA FORM is a fictional direct-to-consumer skincare storefront created to demonstrate e-commerce web design and front-end implementation skills.

## Purpose
This is a portfolio/demo project, not a client project. It was created specifically to demonstrate:
- DTC e-commerce layout and product hierarchy
- Responsive web design
- Product cards and calls to action
- Cart interaction
- Mobile-friendly navigation
- Conversion-oriented content structure
- Clean visual system for a consumer brand

## Stack
- HTML5
- CSS3
- Vanilla JavaScript
- Responsive design
- No external backend/payment processing

## Portfolio positioning
This project is intended to support a Frontend Developer / WordPress / No-Code portfolio. A future WordPress version can be recreated with WordPress + WooCommerce + Elementor.

## Demo limitations
Checkout is a UI demo only. No payment is processed and no real products are sold.

## Author
Adrian Satria Putra
LinkedIn: https://www.linkedin.com/in/adrian-satria-putra
GitHub: https://github.com/adrian-satria
